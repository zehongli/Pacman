#include <time.h>
#include <stdlib.h>
#include <limits.h>
#include <math.h>


#include "ai.h"
#include "utils.h"
#include "priority_queue.h"

#define EPSINON 0.00001


struct heap h;

float get_reward( node_t* n );

/**
 * Function called by pacman.c
*/
void initialize_ai(){
	heap_init(&h);
}

/**
 * function to copy a src into a dst state
*/
void copy_state(state_t* dst, state_t* src){
	//Location of Ghosts and Pacman
	memcpy( dst->Loc, src->Loc, 5*2*sizeof(int) );

    //Direction of Ghosts and Pacman
	memcpy( dst->Dir, src->Dir, 5*2*sizeof(int) );

    //Default location in case Pacman/Ghosts die
	memcpy( dst->StartingPoints, src->StartingPoints, 5*2*sizeof(int) );

    //Check for invincibility
    dst->Invincible = src->Invincible;
    
    //Number of pellets left in level
    dst->Food = src->Food;
    
    //Main level array
	memcpy( dst->Level, src->Level, 29*28*sizeof(int) );

    //What level number are we on?
    dst->LevelNumber = src->LevelNumber;
    
    //Keep track of how many points to give for eating ghosts
    dst->GhostsInARow = src->GhostsInARow;

    //How long left for invincibility
    dst->tleft = src->tleft;

    //Initial points
    dst->Points = src->Points;

    //Remiaining Lives
    dst->Lives = src->Lives;   

}

node_t* create_init_node( state_t* init_state ){
	node_t * new_n = (node_t *) malloc(sizeof(node_t));
	new_n->parent = NULL;	
	new_n->priority = 0;
	new_n->depth = 0;
	new_n->num_childs = 0;
	copy_state(&(new_n->state), init_state);
	new_n->acc_reward =  get_reward( new_n );
	return new_n;
	
}


float heuristic( node_t* n ){
	float h = 0;
	int i = 0, l = 0, g = 0;

	//FILL IN MISSING CODE
	if (n->parent!=NULL){
		if ((n->parent ->state.Invincible == 0) && (n ->state.Invincible == 1)){
			i = 10;
		}

		if ( (n->parent->state.Lives) - (n->state.Lives) == 1){
			l = 10;
		}
	
		if (n->state.Lives < 0){
			g = 100;
		}
	}
	h = i - l - g;

	return h;
}

float get_reward ( node_t* n ){
	float reward = 0;
	
	//FILL IN MISSING CODE
	float value = heuristic(n);
	float score_n = n->state.Points;
	float score_nParent;

	// The change in score from the current node and the parent node
	if (n->parent == NULL){
		score_nParent = score_n;
	}
	else{
		score_nParent = n->parent->state.Points;
	}

	//r(n) = (h(n) + score(n) - score(nParent))  
	reward = value + score_n - score_nParent;

	float discount = pow(0.99,n->depth);
	return discount * reward;
}

/**
 * Apply an action to node n and return a new node resulting from executing the action
*/
bool applyAction(node_t* n, node_t** new_node, move_t action ){

	bool changed_dir = false;

    //FILL IN MISSING CODE
	*new_node = (node_t *) malloc(sizeof(node_t));

	// Updates the state with the action chosen
	copy_state(&( (*new_node)->state ), &(n->state) );
	changed_dir = execute_move_t( &((*new_node)->state), action );

	// A new node points to the parent
	(*new_node)->parent = n;

	(*new_node)->depth = n->depth+1;

	// Updates the priority with negative depth
	(*new_node)->priority = -( (*new_node)->depth );
	(*new_node)->num_childs = 0;
	(*new_node)->acc_reward = get_reward(*new_node);

	if ( (*new_node)->depth == 1 ){
		(*new_node)->move = action;
	}
	else{
		(*new_node)->move = (*new_node)->parent->move;
	}
	return changed_dir;
}

/**
 * Find best action by building all possible paths up to budget
 * and back propagate using either max or avg
 */

move_t get_next_move( state_t init_state, int budget, propagation_t propagation, char* stats ){
	clock_t begin, end;
    double cost;
    begin = clock();

	move_t best_action = rand() % 4;

	float best_action_score[4];
	for(unsigned i = 0; i < 4; i++)
	    best_action_score[i] = INT_MIN;

	unsigned generated_nodes = 0;
	unsigned expanded_nodes = 0;
	unsigned max_depth = 0;
	

	//node <- start
	node_t* n = create_init_node( &init_state );

	//explored <- empty Array
	node_t** explored = malloc(sizeof(node_t*)* budget);
	memset(explored,0,sizeof(node_t*));
	
	// frontier <- priority Queue Containing node Only
	explored[generated_nodes] = n;

	//Use the max heap API provided in priority_queue.h
	//node <- frontier.pop()
	heap_push(&h, n);
	do{
		node_t* h_prior_node = heap_delete(&h);

		// if size(explored) < budget
		if (expanded_nodes < budget){
			expanded_nodes++;

			// for each APPLICABLE action {Left;Right;Up;Downg}
			for (int movement=0; movement<4; movement++){
				
				// filter all un-available actions
				if(applyAction(h_prior_node, &n, movement) == false){
					continue;
					free(explored);
				}
				
				/* newNode <- applyAction(node)
				 * simulate the next move
				 */ 
				node_t* new_node=NULL;
				bool changed_dir = applyAction(h_prior_node, &new_node, movement);

				// propagateBackScoreToFirstAction(newNode)
				if (new_node->depth > max_depth){
					max_depth = new_node->depth;
				}

				h_prior_node->num_childs++;

				generated_nodes++;

				// Memory management
				if (((sizeof(explored)/sizeof(node_t**)) < generated_nodes)){
					explored = (node_t**)realloc(explored, sizeof(node_t*)* 10000);
				}
				
				explored[generated_nodes] = new_node;

				// if lostLife(newNode)
				if (new_node->state.Lives < h_prior_node->state.Lives){
					// node not into queue
				}
				else{
					// frontier.add(newNode)
					heap_push(&h, new_node);
				}
			}

		}
	} while (h.count > 0);
	
	// Calculate the max and avg by looping start at the leaves node backward
	for( int explore_index = generated_nodes; explore_index>-1; explore_index-- ){
		
		node_t* tmp_node = explored[explore_index];

		/* Find the childs location
		 * Add the points reward
		 */
		int counter = 0;
		if (tmp_node->num_childs==0){
			float leaf_acc_reward = 0;
			leaf_acc_reward += tmp_node->acc_reward;
			
			node_t* p_tem_node =tmp_node->parent;
			do{
				leaf_acc_reward += p_tem_node->acc_reward;
				p_tem_node = p_tem_node->parent;
				counter++;
			} while (p_tem_node!=NULL);
			
			//Max
			if (propagation == 0){
				if (leaf_acc_reward > best_action_score[tmp_node->move]){
					best_action_score[tmp_node->move] = leaf_acc_reward;
				}
			}
			
			// Average?
			if (propagation == 1){		
				if ( (leaf_acc_reward/counter) > (best_action_score[tmp_node->move]/counter)){
					best_action_score[tmp_node->move] = (leaf_acc_reward/counter);
				}
			}

		}
	}

	// FreeMemory
	emptyPQ(&h);
		
	// Find the highest score and break the tie		
	int maxIndex = 0;
	int tie = 0;	
	double max = 0;
	for (int i = 0; i< 4; i++){
		if (best_action_score[i] > max){
			max = best_action_score[i];
			maxIndex = i;
		} 
				
		if (((best_action_score[i] - max)>=-EPSINON) && ((best_action_score[i] - max) <= EPSINON) ) {
			tie = i;
		}

		if (best_action_score[maxIndex] > best_action_score[tie]){
			tie = maxIndex;
		}

		//beak the tie randomly
		int k = rand() % 2;
		if (k == 0){
			best_action = tie;
		}
		if (k == 1){
			best_action = maxIndex;
		}
		
	}	


	end = clock();
    cost = (double)(end - begin)/CLOCKS_PER_SEC;

	// output to file
	FILE *fp;  
	fp=fopen("out.txt","w");  

	if(fp==NULL) {  
		printf("File cannot open! " );  
		exit(0);  
	}  
	fprintf(fp,"MaxDepth: %d\n", max_depth);  
	fprintf(fp,"TotalExpanded: %d\n", expanded_nodes);  
	fprintf(fp,"Generated nodes: %d\n", generated_nodes);
	fprintf(fp,"Budget: %d\n", budget);
	fprintf(fp,"Generated nodes: %d\n", generated_nodes);
	fprintf(fp,"time cost is: %lf secs", cost);
	fclose(fp);  
	
	sprintf(stats, "Max Depth: %d Expanded nodes: %d  Generated nodes: %d\n",max_depth,expanded_nodes,generated_nodes);
	
	if(best_action == left)
		sprintf(stats, "%sSelected action: Left\n",stats);
	if(best_action == right)
		sprintf(stats, "%sSelected action: Right\n",stats);
	if(best_action == up)
		sprintf(stats, "%sSelected action: Up\n",stats);
	if(best_action == down)
		sprintf(stats, "%sSelected action: Down\n",stats);

	sprintf(stats, "%sScore Left %f Right %f Up %f Down %f",stats,best_action_score[left],best_action_score[right],best_action_score[up],best_action_score[down]);


	return best_action;
}

